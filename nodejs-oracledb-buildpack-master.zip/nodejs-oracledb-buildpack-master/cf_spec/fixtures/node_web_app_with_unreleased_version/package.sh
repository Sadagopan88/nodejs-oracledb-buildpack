#!/bin/bash -l

rm -rf node_modules
npm install
